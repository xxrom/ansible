#!/bin/bash

spinner() {
  local delay=0.15
  local spinstr='|/-\'
  for ((i = 0; i < 40; i++)); do
    local temp=${spinstr#?}
    printf " [%c]  " "$spinstr"
    local spinstr=$temp${spinstr%"$temp"}
    sleep $delay
    printf "\b\b\b\b\b\b"
  done
  printf "    \b\b\b\b"
}

spinner
