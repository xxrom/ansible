def pp(t: str):
  print('hello', t)


pp()  # print
"""

search by regexp and adding cursors one by one for change
\\/ - open regexp for multi cursor
test ENTER - search by regexp 'test'
n - add next work (N - go to prev word)
q- skip current, jump next (Q - skip prev, jump prev)
i - start changing all selected words


hello world !!!test ashe|
        hello world !!!test
        laksdjf hello world !!!test| asdlfkj laksdjf test
        heasdlfkj hello world !!!test
        asdlkjf
"""
