const foo = (n: number) => {
  return `rrr ${n}`;
};

const tt = "asfd";
foo(tt);
