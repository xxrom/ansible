--local trouble = require("trouble.providers.telescope")

require("telescope").setup({
  defaults = {
    file_ignore_patterns = {
      ".git/",
      ".cache",
      "dist",
      "^node_modules/",
      "%.o",
      "%.a",
      "%.out",
      "%.class",
      "%.pdf",
      "%.mkv",
      "%.mp4",
      "%.zip",
      ".next",
      "node_modules",
      ".git",
    },
    -- Default configuration for telescope goes here:
    -- config_key = value,
    previewer = true,
    color_devicons = true,
    prompt_prefix = "🔍 ",
    scroll_strategy = "cycle",
    sorting_strategy = "ascending",
    layout_strategy = "flex",
    path_display = { "truncate" },
    -- path_display = { shorten = { len = 3, exclude = {3, -3} } },
    -- {"smart", 'truncate', truncate = 3, shorten = 3 }
    -- { shorten = 3 }, -- short all folders
    -- shorten = { len = 3, exclude = {3, -3}} -- full 3 last folder, other -short
    -- shorten = { len = 1, exclude = {1, -1}} -- full 3 first folder, other -short
    layout_config = {
      --preview_height = 0.4,
      cursor = {
        height = 0.9,
        preview_cutoff = 40,
        width = 0.8,
      },
      horizontal = {
        height = 0.9,
        width = 0.97,
        preview_width = 0.5,
        preview_cutoff = 90,
        prompt_position = "bottom",
      },
      vertical = {
        height = 0.99,
        width = 0.99,
        preview_cutoff = 20,
        prompt_position = "top",
      },
      flex = {
        -- switch between vertical <-> horizontal
        -- if < 90 chars => vertical else horizontal
        flip_columns = 90,
      },
      height = 0.99,
      width = 0.99,
    },
    -- Here's how I'm truncating the files in the preview if they're over the file size limit:
    -- https://github.com/nvim-telescope/telescope.nvim/issues/623
    preview = {
      filesize_limit = 10,

      filesize_hook = function(filepath, bufnr, opts)
        local max_bytes = 10000
        local cmd = { "head", "-c", max_bytes, filepath }
        require("telescope.previewers.utils").job_maker(cmd, bufnr, opts)
      end,
    },
    mappings = {
      i = {
        -- map actions.which_key to <C-h> (default: <C-/>)
        -- actions.which_key shows the mappings for your picker,
        -- e.g. git_{create, delete, ...}_branch for the git_branches picker
        ["<C-h>"] = "which_key",
        -- ["<c-t>"] = trouble.open_with_trouble
      },
      -- n = { ["<c-t>"] = trouble.open_with_trouble },
    },
  },
  pickers = {
    -- Default configuration for builtin pickers goes here:
    -- picker_name = {
    --   picker_config_key = value,
    --   ...
    -- }
    -- Now the picker_config_key will be applied every time you call this
    -- builtin picker
  },
  extensions = {
    -- Your extension configuration goes here:
    -- extension_name = {
    --   extension_config_key = value,
    -- }
    -- please take a look at the readme of the extension you want to configure
  },
  file_previewer = require("telescope.previewers").cat.new,
})

-- Implement delta as previewer for diffs
--local previewers = require('telescope.previewers')
--local builtin = require('telescope.builtin')
--local conf = require('telescope.config')
--local E = {}

--local delta = previewers.new_termopen_previewer {
--get_command = function(entry)
---- this is for status
---- You can get the AM things in entry.status. So we are displaying file if entry.status == '??' or 'A '
---- just do an if and return a different command
--if entry.status == '??' or 'A ' then
--return { 'git', '-c', 'core.pager=delta', '-c', 'delta.side-by-side=false', 'diff', entry.value }
--end

---- note we can't use pipes
---- this command is for git_commits and git_bcommits
--return { 'git', '-c', 'core.pager=delta', '-c', 'delta.side-by-side=false', 'diff', entry.value .. '^!' }

--end
--}

--E.my_git_commits = function(opts)
--opts = opts or {}
--opts.previewer = delta

--builtin.git_commits(opts)
--end

--E.my_git_bcommits = function(opts)
--opts = opts or {}
--opts.previewer = delta

--builtin.git_bcommits(opts)
--end

--E.my_git_status = function(opts)
--opts = opts or {}
--opts.previewer = delta

--builtin.git_status(opts)
--end

--return E
