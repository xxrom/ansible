-- Setup nvim-cmp.
local has_words_before = function()
  local line, col = unpack(vim.api.nvim_win_get_cursor(0))
  return col ~= 0
    and vim.api
        .nvim_buf_get_lines(0, line - 1, line, true)[1]
        :sub(col, col)
        :match("%s")
      == nil
end

local feedkey = function(key, mode)
  vim.api.nvim_feedkeys(
    vim.api.nvim_replace_termcodes(key, true, true, true),
    mode,
    true
  )
end

local kind_icons = {
  Text = "",
  Method = "f",
  Function = "f",
  Constructor = "",
  Field = "f",
  Variable = "v",
  Class = "c",
  Interface = "",
  Module = "",
  Property = "p",
  Unit = "",
  Value = "",
  Enum = "",
  Keyword = "",
  Snippet = "",
  Color = "c", -- "",
  File = "f", --"",
  Reference = "",
  Folder = "f", --"",
  EnumMember = "e", --"",
  Constant = "c",
  Struct = "",
  Event = "",
  Operator = "o", -- ",
  TypeParameter = "tp", --",
}

--vim.opt.completeopt = { "menu", "menuone", "noselect" }

local cmp = require("cmp")
if not cmp then
  return
end

cmp.setup({
  completion = {
    keyword_length = 1,
  },
  snippet = {
    expand = function(args)
      require("luasnip").lsp_expand(args.body) -- For `luasnip` users.
    end,
  },
  experimental = {
    ghost_text = true,
  },
  formatting = {
    fields = { "menu", "abbr", "kind" },
    maxwidth = 50, -- prevent the popup from showing more than provided characters (e.g 50 will not show more than 50 characters)
    ellipsis_char = "..", -- when popup menu exceed maxwidth, the truncated part would show ellipsis_char instead (must define maxwidth first)
    format = function(entry, vim_item)
      -- Kind icons
      vim_item.kind =
        string.format("%s %s", kind_icons[vim_item.kind], vim_item.kind) -- This concatonates the icons with the name of the item kind
      -- Source
      vim_item.menu = ({
        buffer = "🗂", -- BUFFER
        nvim_lsp = "⚡️", -- LSP
        luasnip = "🔖", -- LuasSnip
        nvim_lua = "🗞", -- Lua
        path = "📍", -- PATH
      })[entry.source.name]

      return vim_item
    end,
  },
  window = {
    --completion = cmp.config.window.bordered(),
    documentation = cmp.config.window.bordered(),
  },
  mapping = cmp.mapping.preset.insert({
    ["<C-b>"] = cmp.mapping.scroll_docs(-4),
    ["<C-f>"] = cmp.mapping.scroll_docs(4),
    ["<C-Space>"] = cmp.mapping.complete(),
    ["<C-e>"] = cmp.mapping.abort(),
    ["<CR>"] = cmp.mapping.confirm({ select = true }), -- Accept currently selected item. Set `select` to `false` to only confirm explicitly selected items.

    -- for working auto triggering complition changed to S-Tab
    ["<S-Tab>"] = cmp.mapping(function(fallback) -- "Tab"
      if cmp.visible() then
        cmp.select_next_item()
      elseif vim.fn["vsnip#available"](1) == 1 then
        feedkey("<Plug>(vsnip-expand-or-jump)", "")
      elseif has_words_before() then
        cmp.complete()
      else
        fallback() -- The fallback function sends a already mapped key. In this case, it's probably `<Tab>`.
      end
    end, { "i", "s" }),
  }),
  sources = cmp.config.sources({
    { name = "nvim_lsp_signature_help" },
    {
      name = "nvim_lsp",
      keyword_length = 1,
      group_index = 1,
      --entry_filter = function(entry, ctx)
      --local kind = types.lsp.CompletionItemKind[entry:get_kind()]
      --if kind == "Text" then return false end
      --return true
      --end,
    },
    { name = "buffer", keyword_length = 4, group_index = 2 },
    { name = "luasnip", keyword_length = 2, group_index = 2 },
    { name = "path", group_index = 3 },
  }),
})

-- File types specifics
cmp.setup.filetype("gitcommit", {
  sources = cmp.config.sources({
    { name = "cmp_git" },
  }, {
    { name = "buffer" },
  }),
})

-- Command line completion
cmp.setup.cmdline("/", {
  mapping = cmp.mapping.preset.cmdline(),
  sources = { { name = "buffer" } },
})
cmp.setup.cmdline(":", {
  mapping = cmp.mapping.preset.cmdline(),
  sources = cmp.config.sources({
    { name = "path" },
  }, {
    { name = "cmdline" },
  }),
})

--vim.opt.spell = true
--vim.opt.spelllang = { 'en_us' }
--vim.opt.spelloptions = "camel"

-- config [todo] move to v.vim config or separate it to vim-main-config.vim ?
vim.opt.backup = false -- creates a backup file
vim.opt.clipboard = "" -- don't use clipboard
vim.opt.cmdheight = 1 -- more space in the neovim command line for displaying messages
--vim.opt.colorcolumn = "99999" -- fixes indentline for now
vim.opt.colorcolumn = "80" -- Better ???
vim.opt.conceallevel = 0 -- so that `` is visible in markdown files
--vim.opt.cursorline = true -- highlight the current line
vim.opt.expandtab = true -- convert tabs to spaces
vim.opt.fileencoding = "utf-8" -- the encoding written to a file
vim.opt.foldexpr = "" -- set to "nvim_treesitter#foldexpr()" for treesitter based folding
vim.opt.foldmethod = "manual" -- folding set to "expr" for treesitter based folding
vim.opt.hidden = true -- required to keep multiple buffers and open multiple buffers
vim.opt.hlsearch = true -- highlight all matches on previous search pattern
vim.opt.incsearch = true -- highlight life seatch !!!
vim.opt.scrolloff = 8 -- scroll in files always has 8 line of code !!!
vim.opt.list = true
vim.opt.pumheight = 20 -- pop up menu height
vim.opt.showmode = false -- we don't need to see things like -- INSERT -- anymore
vim.opt.smartcase = true -- smart case
vim.opt.smartindent = true -- make indenting smarter again
vim.opt.splitbelow = true -- force all horizontal splits to go below current window
vim.opt.splitright = true -- force all vertical splits to go to the right of current window
vim.opt.swapfile = false -- creates a swapfile
vim.opt.tabstop = 2 -- insert 2 spaces for a tab
vim.opt.termguicolors = false -- set term gui colors (most terminals support this)
vim.opt.timeoutlen = 300 -- timeout length
vim.opt.title = true -- set the title of window to the value of the titlestring
vim.opt.titlestring = "%<%F - nvim" -- what the title of the window will be set to
vim.opt.undodir = vim.fn.stdpath("cache") .. "/undo"
vim.opt.undofile = true -- enable persistent undo
vim.opt.writebackup = false -- if a file is being edited by another program (or was written to file while editing with another program) it is not allowed to be edited

vim.opt.showtabline = 2 -- always show tabs

-- Optimizing speed
vim.opt.synmaxcol = 500 -- 250? syntax rendering
vim.opt.lazyredraw = false -- true -- true -- lazy redrawing
