-- disable netrw at the very start of your init.lua (strongly advised)
vim.g.loaded_netrw = 1
vim.g.loaded_netrwPlugin = 1

-- set termguicolors to enable highlight groups
vim.opt.termguicolors = true

-- Change prefix/character preceding the diagnostics' virtual text
vim.diagnostic.config({
  virtual_text = {
    spacing = 2,
    prefix = "■", -- '⚆→➛➝✧ · • ● ■ ● ▎x'
  },
  severity_sort = true,
  float = {
    focusable = false,
    style = "minimal",
    border = "rounded",
    source = "always",
    header = "",
    prefix = "",
  },
})

vim.lsp.handlers["textDocument/publishDiagnostics"] =
  vim.lsp.with(vim.lsp.diagnostic.on_publish_diagnostics, {
    -- Change the debounce time to a value you prefer, e.g., 1000ms
    debounce = 1000,
  })

vim.lsp.handlers["textDocument/hover"] =
  vim.lsp.with(vim.lsp.handlers.hover, { border = "rounded" })

local function vnim_set_keymap(...)
  vim.api.nvim_set_keymap(...)
end

local opts = { noremap = true, silent = true }
vim.api.nvim_set_keymap(
  "n",
  "[g",
  "<cmd>lua vim.diagnostic.goto_prev()<CR>",
  opts
)
vim.api.nvim_set_keymap(
  "n",
  "]g",
  "<cmd>lua vim.diagnostic.goto_next()<CR>",
  opts
)

local protocol = require("vim.lsp.protocol")

local on_attach = function(client, bufnr)
  local function buf_set_keymap(...)
    vim.api.nvim_buf_set_keymap(bufnr, ...)
  end
  local function buf_set_option(...)
    vim.api.nvim_buf_set_option(bufnr, ...)
  end

  client.server_capabilities.document_formatting = false
  client.server_capabilities.document_range_formatting = false

  if name == "tsserver" then
    local ts_utils = require("nvim-lsp-ts-utils")

    ts_utils.setup({})
    ts_utils.setup_client(client)

    buf_set_keymap("n", "gio", ":TSLspOrganize<CR>", opts)
    buf_set_keymap("n", "grf", ":TSLspRenameFile<CR>", opts)
    buf_set_keymap("n", "gia", ":TSLspImportAll<CR>", opts)
  end

  vim.cmd("command! LspHover lua vim.lsp.buf.hover()")
  buf_set_keymap("n", "K", ":LspHover<CR>", opts)

  vim.cmd([[
    " FORCE set spacing instead of tabs
    set autoindent expandtab tabstop=2 shiftwidth=2
    :retab
  ]])

  local function buf_set_keymap(...)
    vim.api.nvim_buf_set_keymap(bufnr, ...)
  end

  buf_set_keymap("n", "<space>r", "<cmd>lua vim.lsp.buf.rename()<CR>", opts)
  buf_set_keymap(
    "n",
    "<space>ca",
    "<cmd>lua vim.lsp.buf.code_action()<CR>",
    opts
  )

  -- For changing highlight (:hi) do it here!!!
  -- Highlight same words under cursor
  vim.cmd([[
    highlight IlluminatedWordRead guibg=#434358 cterm=none gui=none
    highlight IlluminatedWordWrite guibg=#433040 cterm=none gui=none
    highlight IlluminatedWordText guibg=#433040 cterm=none gui=none
    highlight! Type guifg=#009797
  ]])

  -- Highlight line number instead of having icons in sign column
  vim.cmd([[
    highlight DiagnosticLineNrError guibg=#51202A gui=bold " guifg=#FF0000
    highlight DiagnosticLineNrWarn guibg=#51412A gui=bold " guifg=#FFA500
    highlight DiagnosticLineNrInfo guibg=#1E535D gui=bold " guifg=#00FFFF
    highlight DiagnosticLineNrHint guibg=#1E205D gui=bold " guifg=#0000FF

    sign define DiagnosticSignError text= texthl=DiagnosticSignError linehl= numhl=DiagnosticLineNrError
    sign define DiagnosticSignWarn text= texthl=DiagnosticSignWarn linehl= numhl=DiagnosticLineNrWarn
    sign define DiagnosticSignInfo text= texthl=DiagnosticSignInfo linehl= numhl=DiagnosticLineNrInfo
    sign define DiagnosticSignHint text= texthl=DiagnosticSignHint linehl= numhl=DiagnosticLineNrHint

    " GIT gutter
    highlight! GitGutterAddLineNr guifg=green
    highlight! GitGutterChangeLineNr guifg=lightblue
    highlight! GitGutterDeleteLineNr guifg=lightred
    highlight! GitGutterChangeDeleteLineNr guifg=lightred

    " NVIM "
    " https://github.com/neovim/neovim/pull/15894/files
    " Fixed issue with underline slow rendering !!!
    highlight! DiagnosticError ctermfg=1 guifg=Red
    highlight! DiagnosticWarn ctermfg=3 guifg=Orange
    highlight! DiagnosticInfo ctermfg=4 guifg=LightBlue
    "highlight! DiagnosticHint ctermfg=7 guifg=LightGrey
    " Enabling underline and background for Errors
    "highlight! DiagnosticUnderlineError cterm=unercurl gui=NONE guisp=Red
    "highlight! DiagnosticUnderlineError guifg=NONE guibg=#aa0000 guisp=#ff0000 gui=underline cterm=NONE
    highlight! DiagnosticUnderlineError guifg=NONE guibg=#440000 gui=NONE cterm=NONE
    highlight! DiagnosticUnderlineWarn cterm=underline gui=underline guisp=Orange
    highlight! DiagnosticUnderlineInfo cterm=underline gui=underline guisp=LightBlue
    highlight! DiagnosticUnderlineHint term=underline cterm=underline guisp=LightGrey
  ]])
end

local capabilities_default = require("cmp_nvim_lsp").default_capabilities()
local capabilities_tsx = require("cmp_nvim_lsp").default_capabilities(
  vim.lsp.protocol.make_client_capabilities()
)
local util = require("lspconfig/util")

capabilities_default.textDocument.foldingRange = {
  dynamicRegistration = false,
  lineFoldingOnly = true,
}
capabilities_tsx.textDocument.foldingRange = {
  dynamicRegistration = false,
  lineFoldingOnly = true,
}

local flags500 = {
  debounce_text_changes = 200,
}

-- tsserver
require("lspconfig").tsserver.setup({
  capabilities = capabilities_tsx,
  flags = flags500,
  on_attach = on_attach,
  init_options = { hostInfo = "neovim" },
  cmd = { "typescript-language-server", "--stdio" },
  root_dir = util.root_pattern(
    "package.json",
    "tsconfig.json",
    "jsconfig.json",
    "hardhat.config.*",
    ".git"
  ),
  filetypes = {
    "javascript",
    "javascriptreact",
    "javascript.jsx",
    "typescript",
    "typescriptreact",
    "typescript.tsx",
  },
})

-- eslint
require("lspconfig").eslint.setup({
  capabilities = capabilities_default,
  flags = flags500,
  on_attach = function(client, bufnr)
    vim.api.nvim_create_autocmd("BufWritePre", {
      buffer = bufnr,
      command = "EslintFixAll",
    })
  end,
})

-- tailwindcss
local tw_highlight = require("tailwind-highlight")
require("lspconfig").tailwindcss.setup({
  capabilities = capabilities_default,
  flags = flags500,
  on_attach = function(client, bufnr)
    tw_highlight.setup(client, bufnr, {
      single_column = false,
      mode = "background",
    })
  end,
})

-- html
local capabilities_html = vim.lsp.protocol.make_client_capabilities()
capabilities_html.textDocument.completion.completionItem.snippetSupport = true
require("lspconfig").html.setup({
  capabilities = capabilities_html,
  on_attach = on_attach,
  flags = flags500,
})

-- GraphQL
require("lspconfig").graphql.setup({
  capabilities = capabilities_default,
  flags = flags100,
})

-- python
require("lspconfig").pyright.setup({
  on_attach = on_attach,
  capabilities = capabilities_default,
  flags = flags500,
})

-- GOLANG
require("lspconfig").gopls.setup({
  on_attach = on_attach,
  capabilities = capabilities_default,
  flags = flags500,
  cmd = { "gopls", "serve" },
  filetypes = { "go", "gomod" },
  root_dir = util.root_pattern("go.work", "go.mod", ".git"),
  settings = {
    gopls = {
      analyses = {
        unusedparams = true,
      },
      staticcheck = true,
    },
  },
})
vim.cmd([[
  autocmd FileType go setlocal omnifunc=v:lua.vim.lsp.omnifunc
]])

-- Solidity
require("lspconfig").solang.setup({
  on_attach = on_attach,
  capabilities = capabilities_default,
  flags = flags500,
})

-- CSSmodules
require("lspconfig").cssmodules_ls.setup({
  -- optionally
  init_options = {
    camelCase = "dashes",
  },
  capabilities = capabilities_default,
  on_attach = function(client, bufrn)
    -- avoid accepting `definitionProvider` responses from this LSP
    client.server_capabilities.definitionProvider = false
    on_attach(client, bufrn)
  end,
})

-- Python-lsp-server
--require("lspconfig").pylsp.setup({
--on_attach = on_attach,
--capabilities = capabilities_default,
--flags = {
---- This will be the default in neovim 0.7+
--debounce_text_changes = 150,
--},
--settings = {
---- configure plugins in pylsp
--pylsp = {
--configurationSources = "",
--plugins = {
--pycodestyle = {
--enabled = true,
----exclude= [],-- Exclude files or directories which match these patterns
--ignore = { -- Ignore errors and warnings
--"E501", -- Line too long (82 &gt; 79 characters)
--"W504", -- line break after binary operation
--},
--maxLineLength = 80,
--indentSize = 2, -- Set maximum allowed line length
--},
--yapf = { enabled = true },
--autopep8 = { enabled = false },
--flake8 = { enabled = false },
--pydocstyle = { enabled = false },
--pyflakes = { enabled = false },
--pylint = { enabled = false },
--},
--},
--},
--})

--require("refactoring").setup({})

--require'lspconfig'.pylsp.setup {
--capabilities = capabilities_default,
--cmd = { "pylsp" },
--filetypes = { "python" },
--root_dir = function()
--return vim.fn.getcwd()
--end,
--single_file_support = true,
--configurationSources = {"YAPF"},  -- default is pycodestyle
--rope = {extensionModules = "", ropeFolder = {} },
--plugins = {
--jedi_completion = {
--enabled = true,
--eager = true,
--cache_for = {"numpy", "scipy"}
--},
--jedi_definition = {
--enabled = true,
--follow_imports = true,
--follow_builtin_imports = true,
--},
--jedi_hover = { enabled = true },
--jedi_references = { enabled = true },
--jedi_signature_help = { enabled = true },
--jedi_symbols = { enabled = true, all_scopes = true, include_import_symbols = true },
--preload = { enabled = true, modules = {"numpy", "scipy"} },
--mccabe = { enabled = false },
--mypy = { enabled = false },
--isort = { enabled = false },
--spyder = { enabled = false },
--memestra = { enabled = false },
--pycodestyle = { enabled = false },  -- not work
--flake8 = { enabled = false },
--pyflakes = { enabled = false },
--yapf = { enabled = true },
--pylint = {
--enabled = false,
--},
--rope = { enabled = false },
--rope_completion = { enabled = false, eager = false },
--}
--}

-- TODO: check grammar
-- https://dev.languagetool.org/finding-errors-using-n-gram-data.html
--nvim_lsp.ltex.setup {
--on_attach = on_attach,
--settings = {
--ltex = {
--additionalRules = {
--languageModel = '~/ngrams/',
--},
--},
--},
--}

-- Use LspAttach autocommand to only map the following keys
-- after the language server attaches to the current buffer
vim.api.nvim_create_autocmd("LspAttach", {
  group = vim.api.nvim_create_augroup("UserLspConfig", {}),
  callback = function(ev)
    -- Enable completion triggered by <c-x><c-o>
    vim.bo[ev.buf].omnifunc = "v:lua.vim.lsp.omnifunc"

    -- Buffer local mappings.
    -- See `:help vim.lsp.*` for documentation on any of the below functions
    local opts = { buffer = ev.buf }
    --vim.keymap.set("n", "gD", vim.lsp.buf.declaration, opts)
    --vim.keymap.set("n", "gd", vim.lsp.buf.definition, opts)
    vim.keymap.set("n", "K", vim.lsp.buf.hover, opts)
    vim.keymap.set("n", "<space>d", vim.lsp.buf.implementation, opts)
    vim.keymap.set("n", "<C-k>", vim.lsp.buf.signature_help, opts)
    --vim.keymap.set("n", "<space>wa", vim.lsp.buf.add_workspace_folder, opts)
    --vim.keymap.set("n", "<space>wr", vim.lsp.buf.remove_workspace_folder, opts)
    --vim.keymap.set("n", "<space>wl", function()
    --print(vim.inspect(vim.lsp.buf.list_workspace_folders()))
    --end, opts)
    vim.keymap.set("n", "<space>dt", vim.lsp.buf.type_definition, opts)
    vim.keymap.set("n", "<space>rn", vim.lsp.buf.rename, opts)
    vim.keymap.set({ "n", "v" }, "<space>ca", vim.lsp.buf.code_action, opts)
    vim.keymap.set("n", "gr", vim.lsp.buf.references, opts)
    vim.keymap.set("n", "<space>f", function()
      vim.lsp.buf.format({ async = true })
    end, opts)
  end,
})
