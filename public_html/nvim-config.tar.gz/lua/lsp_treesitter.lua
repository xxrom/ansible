require("nvim-treesitter.configs").setup({
  highlight = {
    enable = true,
    disable = {},
  },
  autotag = {
    enable = false,
    filetypes = {
      "html",
      "javascript",
      "typescript",
      "javascriptreact",
      "typescriptreact",
      "tsx",
      "jsx",
      "rescript",
      "markdown",
      "solidity",
      "lua",
      "json",
      "graphql",
      "gitignore",
      "css",
    },
  },
  indent = {
    enable = false,
    disable = {},
  },
  ensure_installed = {
    "tsx",
    "json",
    "yaml",
    "html",
    "scss",
    "css",
    "javascript",
    "typescript",
    "graphql",
    "bash",
    "python",
    "vim",
    "solidity",
    "lua",
    "json",
    "graphql",
    "gitignore",
    "css",
    "markdown",
  },
})

require("nvim-ts-autotag").setup()

require("nvim-autopairs").setup({
  disable_filetype = { "TelescopePrompt", "vim" },
})

local parser_config = require("nvim-treesitter.parsers").get_parser_configs()
parser_config.tsx.filetype_to_parsername = { "javascript", "typescript.tsx" }

require("hlargs").setup()
