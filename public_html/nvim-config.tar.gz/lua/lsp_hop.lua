--require'hop'.setup { keys = 'etovxqpdygfblzhckisuran', jump_on_sole_occurrence = false }
require("hop").setup({
  keys = "asdghklqwertyuiopxcvbnmfj",
  jump_on_sole_occurrence = false,
})

-- jump on full screen
vim.api.nvim_set_keymap(
  "n",
  "<leader>;", -- "<leader>e",
  "<cmd> lua require'hop'.hint_words({ hint_position = require'hop.hint'.HintPosition.START })<cr>",
  {}
)
-- jump only in curent line
--vim.api.nvim_set_keymap(
--"n",
--"<leader>E",
--"<cmd>lua require'hop'.hint_words({ current_line_only = true, inclusive_jump = true })<cr>",
--{}
--)
-- jump anywhere
--vim.api.nvim_set_keymap("n", "<leader>l", "<cmd>lua require'hop'.hint_anywhere()<cr>", {})

-- one char mode ...
vim.api.nvim_set_keymap(
  "n",
  "<leader>L",
  "<cmd>lua require'hop'.hint_lines({ })<cr>",
  {}
)
vim.api.nvim_set_keymap(
  "n",
  "<leader>l",
  "<cmd>lua require'hop'.hint_patterns({})<cr>",
  {}
)
