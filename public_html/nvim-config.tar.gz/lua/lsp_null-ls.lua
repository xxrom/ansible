--local null_ls = require("null-ls")

--local sources = {
--null_ls.builtins.formatting.prettier.with({
--filetypes = { "markdown" }
--}),
---- Removing Text options from suggestions
----null_ls.builtins.completion.spell,
--}

--null_ls.setup({
--sources = sources
--})
