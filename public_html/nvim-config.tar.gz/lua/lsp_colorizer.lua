vim.cmd([[
  set termguicolors
]])

local colorizer = require("colorizer")

colorizer.setup()
