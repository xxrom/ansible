require("ibl").setup({
  indent = { char = "▏" },
  scope = { enabled = false },
})
