--" Move selected lines !!! top !!!
vim.keymap.set("v", "J", ":m '>+1<CR>gv=gv")
vim.keymap.set("v", "K", ":m '<-2<CR>gv=gv")

-- Search higlights will be in the middle
vim.keymap.set("n", "n", "nzzzv")
vim.keymap.set("n", "N", "Nzzzv")

-- Copy past without lusing buffer
vim.keymap.set("x", "<leader>p", '"_dP') -- copy then select any you want to removeand <leader>p
