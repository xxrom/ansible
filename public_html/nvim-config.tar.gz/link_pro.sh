#!/bin/bash

declare -a filenames=(".tmux.conf" ".alias" ".zshrc")
declare config_folder="pc_configs"
declare osname

spinner() {
  local delay=0.2
  local spinstr='|/-\'
  for ((i = 0; i < 8; i++)); do
    local temp=${spinstr#?}
    printf " [%c]  " "$spinstr"
    local spinstr=$temp${spinstr%"$temp"}
    sleep $delay
    printf "\b\b\b\b\b\b"
  done
  printf "    \b\b\b\b"
}

if [[ "$OSTYPE" == "linux-gnu"* ]]; then
  osname="linux"
elif [[ "$OSTYPE" == "darwin"* ]]; then
  osname="macos"
fi

echo "OS: $osname"

# For each filename
for filename in "${filenames[@]}"; do
  echo "- processing $filename..."
  spinner

  # Backup original file
  if [ -f ~/$filename ]; then
    echo "  - backing up $filename..."
    mv ~/$filename ~/$filename.bak
    spinner
  fi

  # Create a new file that sources the common and OS-specific files
  echo "  - link $filename and $osname configurations..."

  # Unlink old symbolic link
  if [ -L ~/$filename ]; then
    echo "  - unlinking old $filename..."
    unlink ~/$filename

    if [[ $? -ne 0 ]]; then
      echo "  - Failed to unlink $filename. Skipping..."
      continue
    fi
  fi


  ln -s ~/.config/nvim/$config_folder/$filename ~/$filename

  # TODO: os specific configs
  #echo "source ~/.config/nvim/${config_folder}/${filename}_common" > ~/$filename
  #echo "source ~/.config/nvim/${config_folder}/${filename}_$osname" >> ~/$filename
  spinner

  echo "  - $filename processed"
done

echo "Finished!"
