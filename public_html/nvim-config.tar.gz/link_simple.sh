#!/bin/bash
echo 'Create ln for configs for all files in "pc_configs/*" ... '

#declare -a filenames=(".tmux.conf" ".alias" ".zshrc")
declare -a filenames=(".config/kitty/kitty.conf")

for filename in "${filenames[@]}"; do
    if [ -f ~/$filename ]; then
        mv ~/$filename ~/$filename.bak
    fi
    ln -s ~/.config/nvim/pc_configs/$filename ~/$filename
done

echo 'Finished'
